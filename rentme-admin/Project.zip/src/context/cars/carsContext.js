import { createContext } from "react";

const carsContext = createContext();

export default carsContext;